package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    protected EditText Quantidade, Valor;

    protected TextView Resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calcular(View v){
        Valor= findViewById(R.id.Valor);
        Quantidade=findViewById(R.id.Quantidade);
        Resultado= findViewById(R.id.Resultado);

        double valorDolar= Double.parseDouble(Valor.getText().toString());
        double qtdDolar= Double.parseDouble(Quantidade.getText().toString());

        double resultado= valorDolar * qtdDolar;
        Resultado.setText("R$ " +resultado);
    }
}